package com.allunite.playground;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.allunite.playground.model.Beacon;

import java.util.ArrayList;
import java.util.List;

class BeaconsListAdapter extends RecyclerView.Adapter<BeaconsListAdapter.BeaconViewHolder> {

    private List<Beacon> beacons;

    BeaconsListAdapter() {
        this.beacons = new ArrayList<>();
    }

    void addBeacon(Beacon b) {
        beacons.add(0, b);
        notifyDataSetChanged();
    }

    @Override
    public BeaconViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new BeaconViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(R.layout.item_beacon, parent, false));
    }

    @Override
    public void onBindViewHolder(BeaconViewHolder holder, int position) {
        Beacon b = beacons.get(position);
        Context c = holder.tvInfo.getContext();
        holder.tvInfo.setText(c.getString(R.string.beacon_info, b.getId(), b.getMajor(), b.getMinor()));
    }

    @Override
    public int getItemCount() {
        return beacons.size();
    }

    class BeaconViewHolder extends RecyclerView.ViewHolder {

        TextView tvInfo;

        BeaconViewHolder(View view) {
            super(view);

            tvInfo = (TextView) view.findViewById(R.id.tv_info);
        }
    }
}
