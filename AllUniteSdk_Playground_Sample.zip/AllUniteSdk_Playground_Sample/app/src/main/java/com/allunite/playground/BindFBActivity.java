package com.allunite.playground;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.allunite.sdk.AllUniteSdk;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

public class BindFBActivity extends AppCompatActivity {

    public static final String TAG = BindFBActivity.class.getSimpleName();

    LoginButton loginButton;
    Button btBindCurrent;
    CallbackManager callbackManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_fb);
        loginButton = (LoginButton) findViewById(R.id.lb_fb);
        loginButton.setReadPermissions(
                "user_friends",
                "user_birthday",
                "user_about_me",
                "email",
                "user_hometown");

        callbackManager = CallbackManager.Factory.create();
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                setBindButtonVisibility();
            }

            @Override
            public void onCancel() {
            }

            @Override
            public void onError(FacebookException error) {
                Log.e(TAG, "FacebookCallback onError", error);
            }
        });

        btBindCurrent = (Button) findViewById(R.id.bt_bind_current);
        btBindCurrent.setOnClickListener(v -> requestUserProfileAndBind());
        setBindButtonVisibility();
    }

    private void setBindButtonVisibility() {
        btBindCurrent.setVisibility(AccessToken.getCurrentAccessToken() != null ? View.VISIBLE : View.INVISIBLE);
    }

    private void requestUserProfileAndBind() {
        if (AccessToken.getCurrentAccessToken() == null)
            return;

        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setTitle(getString(R.string.please_wait));
        dialog.show();

        GraphRequest graphRequest = new GraphRequest(
                AccessToken.getCurrentAccessToken(),
                "/me",
                null,
                HttpMethod.GET,
                response -> {
                    Log.d(TAG, String.format("requestUserProfileAndBind response: %s",
                            response != null ? response.getRawResponse() : null));
                    dialog.dismiss();

                    if (response != null) {
                        AllUniteSdk.bindFBProfile(response.getRawResponse(),
                                AccessToken.getCurrentAccessToken().getToken());
                    }
                }
        );
        Bundle parameters = new Bundle();
        parameters.putString("fields",
                "id,email,first_name,gender,last_name,link,locale,name,timezone,updated_time,verified,age_range,friends");
        graphRequest.setParameters(parameters);
        graphRequest.executeAsync();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (callbackManager != null)
            callbackManager.onActivityResult(requestCode, resultCode, data);
    }
}
