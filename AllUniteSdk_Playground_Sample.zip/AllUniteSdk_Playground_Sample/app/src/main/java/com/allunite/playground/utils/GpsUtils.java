package com.allunite.playground.utils;

import android.content.Context;
import android.location.LocationManager;
import android.util.Log;

public abstract class GpsUtils {

    public static final String TAG = GpsUtils.class.getSimpleName();

    public static boolean isGpsEnabled(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean isGPSEnabled = false;
        boolean isNetworkEnabled = false;
        try {
            isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "isGpsEnabled", e);
        }
        return isGPSEnabled || isNetworkEnabled;
    }
}
