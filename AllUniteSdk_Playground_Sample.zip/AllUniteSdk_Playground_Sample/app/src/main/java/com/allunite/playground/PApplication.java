package com.allunite.playground;

import android.app.Application;

import com.allunite.sdk.AllUniteSdk;

public class PApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        AllUniteSdk.setDebuggable(true);
    }
}
