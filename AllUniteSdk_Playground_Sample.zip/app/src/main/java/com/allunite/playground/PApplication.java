package com.allunite.playground;

import android.app.Application;

import com.allunite.sdk.AllUniteSdk;
import com.allunite.sdk.AllUniteSdkApp;

public class PApplication extends AllUniteSdkApp {

    @Override
    public void onCreate() {
        super.onCreate();
        AllUniteSdk.setDebuggable(true);
    }
}
