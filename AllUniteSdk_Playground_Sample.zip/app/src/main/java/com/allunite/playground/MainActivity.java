package com.allunite.playground;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.StringRes;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.allunite.playground.model.Beacon;
import com.allunite.playground.utils.GpsUtils;
import com.allunite.sdk.AllUniteSdk;
import com.allunite.sdk.callbacks.IActionListener;
import com.allunite.sdk.callbacks.IDidFindBeaconListener;

public class MainActivity extends AppCompatActivity implements IDidFindBeaconListener {

    public static final String TAG = MainActivity.class.getSimpleName();

    private static final int REQUEST_LOCATION_PERMISSION = 324;
    private static final int REQUEST_STORAGE_PERMISSION = 325;

    Button btEnable;
    Button btDisable;
    Button btInit;
    Button btTrack;
    Button btTrackDeviceStatus;

    TextView tvLastBeacon;
    RecyclerView rvBeacons;
    BeaconsListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initViews();
        bindButtons();
        checkAndRequestPermissions();

        AllUniteSdk.parseIncomingIntent(this, getIntent(), "playground");
        if (savedInstanceState == null)
            checkGpsEnabled();
    }

    private void checkGpsEnabled() {
        if (!GpsUtils.isGpsEnabled(this)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this)
                    .setTitle(R.string.gps)
                    .setMessage(R.string.gps_is_disabled)
                    .setNegativeButton(R.string.settings, (dialog, which) -> {
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(intent);
                        dialog.dismiss();
                    })
                    .setPositiveButton(R.string.no_thanks, (dialog, which) -> dialog.dismiss());
            builder.show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AllUniteSdk.addDidFindBeaconListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        AllUniteSdk.removeDidFindBeaconListener(this);
    }

    private void bindButtons() {

        btEnable.setOnClickListener(v -> {
            /*Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("playground://allunite-sdk-mode?enable=true"));
            MainActivity.this.startActivity(intent); */
            AllUniteSdk.setSdkEnabled(this,true);
            showSnackBar(R.string.enable_sdk);
        });
        btDisable.setOnClickListener(v -> {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("playground://allunite-sdk-mode?enable=false"));
            MainActivity.this.startActivity(intent);
            showSnackBar(R.string.disable_sdk);
        });
        btInit.setOnClickListener(v -> {
            AllUniteSdk.init(MainActivity.this, new IActionListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onSuccess() {

                }

                @Override
                public void onError(Throwable throwable) {

                }
            });
            showSnackBar(R.string.send_init_request);
        });
        btTrack.setOnClickListener(v -> {
            AllUniteSdk.track(MainActivity.this, "test", "id");
            showSnackBar(R.string.send_tracking);
        });
        btTrackDeviceStatus.setOnClickListener(v -> {
            AllUniteSdk.trackDeviceStatus(MainActivity.this);
        });
    }

    private void checkAndRequestPermissions() {
        checkLocationPermission();
    }

    public void checkLocationPermission() {
        if (!isLocationPermissionGranted()) {
            requestLocationPermission();
        }
        if (!isStoragePermissionGranted()) {
            requestStoragePermission();
        }
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION_PERMISSION);
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
    }

    private void showSnackBar(@StringRes int stringResId) {
        //Snackbar.make(getWindow().getDecorView().getRootView(), stringResId, Snackbar.LENGTH_SHORT).show();
        Snackbar.make(btInit, stringResId, Snackbar.LENGTH_SHORT).show();
    }

    public boolean isLocationPermissionGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    public boolean isStoragePermissionGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void initViews() {
        setContentView(R.layout.activity_main);
        btEnable = findViewById(R.id.bt_enable);
        btDisable = findViewById(R.id.bt_disable);
        btInit = findViewById(R.id.bt_init);
        btTrack = findViewById(R.id.bt_track);
        btTrackDeviceStatus = findViewById(R.id.bt_track_device_state);
        tvLastBeacon = findViewById(R.id.tv_last_beacon);
        rvBeacons = findViewById(R.id.rv_beacons);
        rvBeacons.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BeaconsListAdapter();
        rvBeacons.setAdapter(adapter);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        Log.e(TAG, String.format("onNewIntent: %s", intent));
        AllUniteSdk.parseIncomingIntent(this, intent, "playground");
        super.onNewIntent(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AllUniteSdk.sendLocationPermissionsGranted(this);
        }
    }

    @Override
    public void didFindBeacon(String id, Integer major, Integer minor) {
        rvBeacons.post(() -> {
            adapter.addBeacon(new Beacon(id, major, minor));
            showSnackBar(R.string.found_new_beacon);
        });
    }
}