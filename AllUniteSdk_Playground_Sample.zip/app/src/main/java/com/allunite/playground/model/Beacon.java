package com.allunite.playground.model;

public class Beacon {

    String id;
    Integer major;
    Integer minor;

    public Beacon(String id, Integer major, Integer minor) {
        this.id = id;
        this.major = major;
        this.minor = minor;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getMajor() {
        return major;
    }

    public void setMajor(Integer major) {
        this.major = major;
    }

    public Integer getMinor() {
        return minor;
    }

    public void setMinor(Integer minor) {
        this.minor = minor;
    }
}
