package com.allunite.playground;

/**
 * Created by Tuccro on 28.03.17.
 */

public abstract class Constants {

    public static final String ACCOUNT_ID = "Ardas test";
    public static final String ACCOUNT_KEY = "287708C2BE7048A3B4D8518D84E642B3";
    public static final String BINDING_DEEP_LINK = "allunite://test";

}
