#!/bin/sh

git archive -o AllUniteSdk_Playground_Sample.zip HEAD
